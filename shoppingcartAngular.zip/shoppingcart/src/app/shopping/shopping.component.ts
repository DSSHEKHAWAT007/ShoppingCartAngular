import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Shop } from '../models/shop';
import { ApiService } from '../services/api.service';

@Component({
  selector: 'app-shopping',
  templateUrl: './shopping.component.html',
  styleUrls: ['./shopping.component.css']
})
export class ShoppingComponent implements OnInit {

  data: Shop;
  receiptData : any;

   options: string[] = ["book", "music cd", "chocolate bar","box of chocolates","bottle of perfume","packet of headache pills"];

  constructor(    public apiService: ApiService,
    public router: Router) {

      this.data = new Shop();

     }



  ngOnInit(): void {

    this.data.Name = "book";
  }


  submitForm() {
    this.apiService.createItem(this.data).subscribe((response) => {

      this.receiptData = response;

      console.log(this.receiptData);

    });
  }

}
