export class Shop {
    Name: string;
    Price: number;
    IsImported: boolean;
    Quantity: number;
}
