import { Shop } from './shop';

describe('Shop', () => {
  it('should create an instance', () => {
    expect(new Shop()).toBeTruthy();
  });
});
